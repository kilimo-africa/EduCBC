package com.strathmore.educbc.quiz;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DataResponse {
    @SerializedName("data")
    @Expose
    private List<RetroQuestion> data = null;

    public List<RetroQuestion> getData() {
        return data;
    }

    public void setData(List<RetroQuestion> data) {
        this.data = data;
    }
}
