package com.strathmore.educbc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class PlayActivity extends AppCompatActivity {
    private static final String LOG_TAG = PlayActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
    }

    public void launchTicTacToeActivity(View view) {
        Log.d(LOG_TAG, "Tic Tac Toe Button Clicked");

        Intent intent = new Intent(this, TicTacToeActivity.class);

        startActivity(intent);
    }

    public void launchBrainTrainerActivity(View view) {
        Log.d(LOG_TAG, "Brain Trainer Button Clicked");

        Intent intent = new Intent(this, BrainTrainerActivity.class);

        startActivity(intent);
    }
}
