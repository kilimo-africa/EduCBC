package com.strathmore.educbc.quiz;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ServiceInterface {
    @GET("questions")
    Call<DataResponse> getQuestions();

    @POST("saveResult")
    @FormUrlEncoded
    Call<ResultsResponse> saveResult(@Field("user_id") int user_id,
                                     @Field("score") String score,
                                     @Field("subject_id") int subject_id);
}
