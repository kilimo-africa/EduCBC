package com.strathmore.educbc.quiz;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResultsResponse {
    @SerializedName("data")
    @Expose
    private List<RetroAnswers> data = null;

    public List<RetroAnswers> getData() {
        return data;
    }

    public void setData(List<RetroAnswers> data) {
        this.data = data;
    }
}
