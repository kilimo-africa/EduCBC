package com.strathmore.educbc.quiz;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RetroQuestion {
    @SerializedName("id")
    @Expose
    private int id;
    @SerializedName("question")
    @Expose
    private String question;
    @SerializedName("subject_id")
    @Expose
    private int subjectId;
    @SerializedName("choice1")
    @Expose
    private String choice1;
    @SerializedName("choice2")
    @Expose
    private String choice2;
    @SerializedName("choice3")
    @Expose
    private String choice3;
    @SerializedName("choice4")
    @Expose
    private String choice4;
    @SerializedName("answer")
    @Expose
    private String answer;

    /*
    public RetroQuestion(Integer id, String question, int subjectId, String choice1,String choice2,String choice3,String choice4, String answer ) {
        this.id = id;
        this.question = question;
        this.subjectId = subjectId;
        this.choice1 = choice1;
        this.choice2 = choice2;
        this.choice3 = choice3;
        this.choice4 = choice4;
        this.answer = answer;
    }
    */

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public String getChoice1() {
        return choice1;
    }

    public void setChoice1(String choice1) {
        this.choice1 = choice1;
    }

    public String getChoice2() {
        return choice2;
    }

    public void setChoice2(String choice2) {
        this.choice2 = choice2;
    }

    public String getChoice3() {
        return choice3;
    }

    public void setChoice3(String choice3) {
        this.choice3 = choice3;
    }

    public String getChoice4() {
        return choice4;
    }

    public void setChoice4(String choice4) {
        this.choice4 = choice4;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
