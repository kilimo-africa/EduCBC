package com.strathmore.educbc.quiz;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.strathmore.educbc.R;

import java.util.List;

public class QuestionsAdapter extends RecyclerView.Adapter<QuestionsAdapter.ViewHolder> {
    private List<RetroQuestion> mData;
    private Context mContext;

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView questionText;
        public Button choiceButton1;
        public Button choiceButton2;
        public Button choiceButton3;
        public Button choiceButton4;

        public ViewHolder(View dataView) {
            super(dataView);
            questionText = dataView.findViewById(R.id.question);
            choiceButton1 = dataView.findViewById(R.id.choice1);
            choiceButton2 = dataView.findViewById(R.id.choice2);
            choiceButton3 = dataView.findViewById(R.id.choice3);
            choiceButton4 = dataView.findViewById(R.id.choice4);
        }
    }

    public QuestionsAdapter(Context context, List<RetroQuestion> data) {
        mData = data;
        mContext = context;
    }

    @Override
    public QuestionsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View questionView = inflater.inflate(R.layout.row_layout, parent, false);

        ViewHolder viewHolder = new ViewHolder(questionView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        RetroQuestion question = mData.get(position);
        TextView textView = holder.questionText;
        Button button1 = holder.choiceButton1;
        Button button2 = holder.choiceButton2;
        Button button3 = holder.choiceButton3;
        Button button4 = holder.choiceButton4;

        textView.setText(question.getQuestion());
        button1.setText(question.getChoice1());
        button2.setText(question.getChoice2());
        button3.setText(question.getChoice3());
        button4.setText(question.getChoice4());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void updateQuestions(List<RetroQuestion> data) {
        mData = data;
        notifyDataSetChanged();
    }


    private RetroQuestion getItem(int adapterPosition) {
        return mData.get(adapterPosition);
    }

    public interface PostItemListener {
        void onPostClick(long id);
    }
}
