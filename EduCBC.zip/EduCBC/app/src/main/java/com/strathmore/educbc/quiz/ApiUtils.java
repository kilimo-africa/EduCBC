package com.strathmore.educbc.quiz;

public class ApiUtils {
    public static final String BASE_URL = "http://tangused.com/api/";

    public static ServiceInterface getSIService() {
        return RetrofitClient.getClient(BASE_URL).create(ServiceInterface.class);

    }
}
