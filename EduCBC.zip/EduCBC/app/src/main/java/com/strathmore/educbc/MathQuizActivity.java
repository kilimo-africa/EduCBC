package com.strathmore.educbc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.strathmore.educbc.quiz.ApiUtils;
import com.strathmore.educbc.quiz.DataResponse;
import com.strathmore.educbc.quiz.QuestionsAdapter;
import com.strathmore.educbc.quiz.RetroQuestion;
import com.strathmore.educbc.quiz.ServiceInterface;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MathQuizActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ServiceInterface mService;
    private QuestionsAdapter mAdapter;

    Button startButton;
    TextView resultTextView;
    TextView pointsTextView;
    Button button1;
    Button button2;
    Button button3;
    Button button4;

    TextView timerTextView;
    Button playAgainButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math_quiz);

        startButton

        mService = ApiUtils.getSIService();
        mRecyclerView = findViewById(R.id.myRecyclerView);
        mAdapter = new QuestionsAdapter(this, new ArrayList<RetroQuestion>(0));

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);

        loadQuestions();
    }

    public void loadQuestions() {
        mService.getQuestions().enqueue(new Callback<DataResponse>() {
            @Override
            public void onResponse(Call<DataResponse> call, Response<DataResponse> response) {

                if(response.isSuccessful()) {
                    mAdapter.updateQuestions(response.body().getData());
                    Log.d("MainActivity", "Questions loaded from API");

                }else {
                    int statusCode  = response.code();
                    // handle request errors depending on status code
                    Log.d("Error", "Not Loading" + " " + statusCode);
                }
            }

            @Override
            public void onFailure(Call<DataResponse> call, Throwable t) {
                if (t instanceof IOException) {
                    Toast.makeText(MathQuizActivity.this, "this is an actual network failure :( inform the user and possibly retry" + t, Toast.LENGTH_SHORT).show();
                    // logging probably not necessary
                    Log.d("Error", "Error: " + t);
                }
                else {
                    Toast.makeText(MathQuizActivity.this, "conversion issue! big problems :(", Toast.LENGTH_SHORT).show();
                    // todo log to some central bug tracking service
                }

                //showErrorMessage();
                Log.d("MainActivity", "error loading from API");
                /* Toast.makeText(MainActivity.this, "Unable to load Questions", Toast.LENGTH_SHORT)
                        .show();
                        */
            }
        });
    }

    public void start(View view) {

    }
}
